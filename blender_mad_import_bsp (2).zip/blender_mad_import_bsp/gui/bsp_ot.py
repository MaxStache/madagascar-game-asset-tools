from bpy.types import Operator
from bpy_extras.io_utils import ImportHelper
from bpy.props import StringProperty, FloatProperty, BoolProperty

from ..bspLib import parse_file as parse_bsp_file
from ..bspLib import collect_atomic_sectors

# ── Modal phases ──────────────────────────────────────────────────────────────
_PH_GEOM       = 0   # build flat vertex/face lists from sectors (batched)
_PH_UNION      = 1   # union-find to discover connected components (one tick)
_PH_COMPONENTS = 2   # bounding boxes per component (one tick)
_PH_CLUSTER    = 3   # grid-based O(n) proximity clustering (one tick)
_PH_ZONES      = 4   # pre-compute per-zone Python geometry (one tick)
_PH_MESHES     = 5   # create Blender mesh objects (one zone per tick)

_SECTORS_PER_TICK = 20   # geometry-building batch size


class IMPORT_OT_bsp(Operator, ImportHelper):
    bl_idname = "import_scene.bsp"
    bl_label = "Import BSP"
    bl_options = {'PRESET', 'UNDO'}

    filename_ext = ".bsp"
    filter_glob: StringProperty(default="*.bsp", options={'HIDDEN'}) # type: ignore

    scale: FloatProperty(
        name="Scale",
        description="Scale factor for imported geometry",
        default=3,
        min=0.000001,
        max=1000.0,
    ) # type: ignore

    center_geometry: BoolProperty(
        name="Center Geometry",
        description="Move all geometry to be centered at the origin",
        default=True,
    ) # type: ignore

    cluster_distance: FloatProperty(
        name="Cluster Distance",
        description="Sectors farther apart than this are imported as separate meshes (0 = single mesh)",
        default=10000.0,
        min=0.0,
        max=100000000.0,
    ) # type: ignore

    distribute_zones: BoolProperty(
        name="Distribute Zones",
        description="Arrange zones in a circle around the origin for easy viewing",
        default=False,
    ) # type: ignore

    distribute_radius: FloatProperty(
        name="Distribution Radius",
        description="Radius of the circle for zone distribution",
        default=1000.0,
        min=0.0,
        max=100000.0,
    ) # type: ignore

    texture_prefix: StringProperty(
        name="Texture Prefix",
        description="Path prefix for textures relative to BSP location (e.g., 'textures/' or '../shared/')",
        default="",
    ) # type: ignore

    recalc_normals: BoolProperty(
        name="Recalculate Normals",
        description="Recalculate face normals to be consistent (disable if your BSP has intentional double-sided geometry)",
        default=False,
    ) # type: ignore

    def execute(self, context):
        import os
        import bpy
        import math
        import random

        if os.path.isdir(self.filepath):
            self.report({'ERROR'}, "Selected path is a folder, please select a BSP file.")
            return {'CANCELLED'}

        try:
            parsed_bsp = parse_bsp_file(self.filepath)
        except Exception as e:
            self.report({'ERROR'}, f"Failed to parse BSP: {e}")
            return {'CANCELLED'}

        sectors = collect_atomic_sectors(parsed_bsp.get("worldChunk", []))
        if not sectors:
            self.report({'ERROR'}, "No geometry found in BSP")
            return {'CANCELLED'}

        materials = parsed_bsp.get("materialList", {}).get("materials", [])

        # ── Pre-scan vertex alpha so we can flag transparent materials ──────
        ALPHA_THRESHOLD = 254
        materials_with_vertex_alpha = set()
        for sector in sectors:
            if sector.get("isNativeData"):
                continue
            sector_colors = sector.get("colors", [])
            mat_base = sector.get("matListWindowBase", 0)
            for tri in sector.get("triangles", []):
                mat_idx = mat_base + tri.get("materialIndex", 0)
                for vi in (tri["vertex1"], tri["vertex2"], tri["vertex3"]):
                    if vi < len(sector_colors) and sector_colors[vi].get("a", 255) < ALPHA_THRESHOLD:
                        materials_with_vertex_alpha.add(mat_idx)
                        break

        # ── Build Blender materials ──────────────────────────────────────────
        mat_suffix = str(random.randint(1000, 9999))
        bsp_name = os.path.splitext(os.path.basename(self.filepath))[0]
        bsp_dir  = os.path.dirname(self.filepath)

        blender_materials = []
        for i, mat in enumerate(materials):
            bl_mat = bpy.data.materials.new(name=f"{bsp_name}_mat_{i}_{mat_suffix}")
            bl_mat.use_nodes = True
            bl_mat.use_backface_culling = False

            nodes = bl_mat.node_tree.nodes
            links = bl_mat.node_tree.links
            bsdf  = nodes.get("Principled BSDF")

            if bsdf:
                color = mat.get("color", {})
                r = color.get("r", 255) / 255.0
                g = color.get("g", 255) / 255.0
                b = color.get("b", 255) / 255.0
                a = color.get("a", 255) / 255.0
                bsdf.inputs["Base Color"].default_value = (r, g, b, 1.0)

                vcol = nodes.new(type="ShaderNodeVertexColor")
                vcol.layer_name = "Color"
                vcol.location = (-650, 300)
                bsdf.inputs["Roughness"].default_value = 1.0 - mat.get("specular", 0.0)

                is_transparent = (
                    a < 0.999
                    or mat.get("isTransparent", False)
                    or mat.get("hasAlpha", False)
                    or mat.get("alphaBlend", False)
                    or i in materials_with_vertex_alpha
                )
                if is_transparent:
                    bsdf.inputs["Alpha"].default_value = a

                if mat.get("isTextured") and mat.get("texture"):
                    tex_name = mat["texture"].get("diffuseTextureName", "")
                    if tex_name:
                        tex_node = nodes.new(type="ShaderNodeTexImage")
                        tex_node.location   = (-300, 300)
                        tex_node.label      = tex_name
                        tex_node.interpolation = 'Closest'
                        tex_path = os.path.join(bsp_dir, self.texture_prefix, f"{tex_name}.png")
                        try:
                            image = bpy.data.images.load(tex_path, check_existing=True)
                        except Exception:
                            image = bpy.data.images.new(name=tex_name, width=1, height=1)
                            image.filepath = tex_path
                            image.source   = 'FILE'
                        tex_node.image = image

                        if is_transparent:
                            mul = nodes.new(type="ShaderNodeMath")
                            mul.operation = 'MULTIPLY'
                            mul.location  = (-100, 100)
                            links.new(tex_node.outputs["Alpha"], mul.inputs[0])
                            links.new(vcol.outputs["Alpha"],     mul.inputs[1])
                            links.new(mul.outputs["Value"],      bsdf.inputs["Alpha"])

                        mix = nodes.new(type="ShaderNodeMixRGB")
                        mix.blend_type = 'MULTIPLY'
                        mix.inputs["Fac"].default_value = 1.0
                        mix.location = (-100, 300)
                        links.new(tex_node.outputs["Color"], mix.inputs["Color1"])
                        links.new(vcol.outputs["Color"],     mix.inputs["Color2"])
                        links.new(mix.outputs["Color"],      bsdf.inputs["Base Color"])
                    else:
                        links.new(vcol.outputs["Color"], bsdf.inputs["Base Color"])
                        if is_transparent:
                            links.new(vcol.outputs["Alpha"], bsdf.inputs["Alpha"])
                else:
                    links.new(vcol.outputs["Color"], bsdf.inputs["Base Color"])
                    if is_transparent:
                        links.new(vcol.outputs["Alpha"], bsdf.inputs["Alpha"])

                if hasattr(bl_mat, "surface_render_method"):
                    bl_mat.surface_render_method = 'BLENDED' if is_transparent else 'DITHERED'
                else:
                    if is_transparent:
                        bl_mat.blend_method = 'BLEND'
                        if hasattr(bl_mat, "shadow_method"):
                            bl_mat.shadow_method = 'HASHED'
                    else:
                        bl_mat.blend_method = 'OPAQUE'

            blender_materials.append(bl_mat)

        # ── Create parent empty ──────────────────────────────────────────────
        world_parent = bpy.data.objects.new(bsp_name, None)
        context.collection.objects.link(world_parent)
        world_parent.rotation_euler[0] = math.radians(90)

        # ── Store all state needed by modal ──────────────────────────────────
        self._phase              = _PH_GEOM
        self._sectors            = sectors
        self._sector_idx         = 0          # for batched geom building
        self._all_verts          = []
        self._all_faces          = []
        self._all_face_mats      = []
        self._all_uvs            = []
        self._all_colors         = []
        self._vertex_offset      = 0
        self._blender_materials  = blender_materials
        self._world_parent       = world_parent
        self._bsp_name           = bsp_name
        self._scale              = self.scale
        self._center_geometry    = self.center_geometry
        self._cluster_distance   = self.cluster_distance
        self._recalc             = self.recalc_normals
        self._dist_zones         = self.distribute_zones
        self._dist_radius        = self.distribute_radius
        self._zones_list         = None
        self._zone_idx           = 0
        self._total_zones        = 0
        # union-find / component state set during _PH_UNION / _PH_COMPONENTS
        self._uf_parent          = None
        self._components         = None
        self._comp_parent        = None

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.001, window=context.window)
        wm.modal_handler_add(self)
        wm.progress_begin(0, 100)
        return {'RUNNING_MODAL'}

    # ── Modal ─────────────────────────────────────────────────────────────────

    def modal(self, context, event):
        import bpy
        import bmesh
        import math

        if event.type != 'TIMER':
            return {'PASS_THROUGH'}

        wm = context.window_manager

        # ── Phase 0: build geometry lists (batch of sectors per tick) ────────
        if self._phase == _PH_GEOM:
            sectors    = self._sectors
            n_sectors  = len(sectors)
            end_idx    = min(self._sector_idx + _SECTORS_PER_TICK, n_sectors)

            for si in range(self._sector_idx, end_idx):
                sector   = sectors[si]
                if sector.get("isNativeData"):
                    continue
                vertices  = sector.get("vertices", [])
                uvs       = sector.get("uvs", [])
                colors    = sector.get("colors", [])
                triangles = sector.get("triangles", [])
                mat_base  = sector.get("matListWindowBase", 0)
                if not vertices:
                    continue

                for i, v in enumerate(vertices):
                    self._all_verts.append((v["x"], v["y"], v["z"]))
                    self._all_uvs.append(
                        (uvs[i]["u"], 1.0 - uvs[i]["v"]) if uvs and i < len(uvs) else (0.0, 0.0)
                    )
                    if colors and i < len(colors):
                        c = colors[i]
                        self._all_colors.append((
                            c.get("r", 255) / 255.0,
                            c.get("g", 255) / 255.0,
                            c.get("b", 255) / 255.0,
                            c.get("a", 255) / 255.0,
                        ))
                    else:
                        self._all_colors.append((1.0, 1.0, 1.0, 1.0))

                vo = self._vertex_offset
                for tri in triangles:
                    self._all_faces.append((
                        tri["vertex1"] + vo,
                        tri["vertex2"] + vo,
                        tri["vertex3"] + vo,
                    ))
                    self._all_face_mats.append(mat_base + tri.get("materialIndex", 0))
                self._vertex_offset += len(vertices)

            self._sector_idx = end_idx
            pct = int(self._sector_idx / n_sectors * 25)
            wm.progress_update(pct)

            if self._sector_idx >= n_sectors:
                if not self._all_faces:
                    self.report({'ERROR'}, "No geometry found")
                    self._cancel_modal(context)
                    return {'CANCELLED'}
                self._phase = _PH_UNION

        # ── Phase 1: union-find connected components (one tick) ───────────────
        elif self._phase == _PH_UNION:
            n   = len(self._all_verts)
            par = list(range(n))
            self._uf_parent = par

            def find(x):
                while par[x] != x:
                    par[x] = par[par[x]]   # path halving
                    x = par[x]
                return x

            for v1, v2, v3 in self._all_faces:
                r1 = find(v1); r2 = find(v2); r3 = find(v3)
                if r1 != r2: par[r1] = r2; r2 = find(r2)
                if r2 != r3: par[r2] = r3

            wm.progress_update(30)
            self._phase = _PH_COMPONENTS

        # ── Phase 2: bounding boxes per component (one tick) ──────────────────
        elif self._phase == _PH_COMPONENTS:
            par         = self._uf_parent
            all_verts   = self._all_verts
            all_faces   = self._all_faces
            all_face_m  = self._all_face_mats

            def find(x):
                while par[x] != x:
                    par[x] = par[par[x]]
                    x = par[x]
                return x

            comp_faces = {}
            for fi, face in enumerate(all_faces):
                root = find(face[0])
                comp_faces.setdefault(root, []).append(fi)

            components = []
            for face_indices in comp_faces.values():
                vi = set()
                for fi in face_indices:
                    vi.update(all_faces[fi])
                xs = [all_verts[v][0] for v in vi]
                ys = [all_verts[v][1] for v in vi]
                zs = [all_verts[v][2] for v in vi]
                components.append({
                    "face_indices": face_indices,
                    "vert_indices": vi,
                    "bbox": (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs)),
                })

            self._components = components
            self._comp_parent = list(range(len(components)))
            wm.progress_update(40)
            self._phase = _PH_CLUSTER

        # ── Phase 3: grid-based O(n) clustering (one tick) ───────────────────
        elif self._phase == _PH_CLUSTER:
            components     = self._components
            comp_par       = self._comp_parent
            cluster_dist   = self._cluster_distance

            cp = comp_par
            def find_c(x):
                while cp[x] != x:
                    cp[x] = cp[cp[x]]
                    x = cp[x]
                return x
            def union_c(x, y):
                rx, ry = find_c(x), find_c(y)
                if rx != ry: cp[rx] = ry

            if cluster_dist > 0:
                cell = cluster_dist  # grid cell size equals cluster distance

                # Assign each component to a grid cell by its bbox centre
                grid = {}
                centres = []
                for i, comp in enumerate(components):
                    b  = comp["bbox"]
                    cx = (b[0] + b[1]) * 0.5
                    cy = (b[2] + b[3]) * 0.5
                    cz = (b[4] + b[5]) * 0.5
                    centres.append((cx, cy, cz))
                    gk = (int(cx // cell), int(cy // cell), int(cz // cell))
                    grid.setdefault(gk, []).append(i)

                def bbox_dist(b1, b2):
                    def ax(lo1, hi1, lo2, hi2):
                        if hi1 < lo2: return lo2 - hi1
                        if hi2 < lo1: return lo1 - hi2
                        return 0.0
                    dx = ax(b1[0], b1[1], b2[0], b2[1])
                    dy = ax(b1[2], b1[3], b2[2], b2[3])
                    dz = ax(b1[4], b1[5], b2[4], b2[5])
                    return (dx*dx + dy*dy + dz*dz) ** 0.5

                # Only compare components in the same or adjacent cells (27 neighbours)
                for i, comp in enumerate(components):
                    cx, cy, cz = centres[i]
                    gx = int(cx // cell)
                    gy = int(cy // cell)
                    gz = int(cz // cell)
                    for ddx in (-1, 0, 1):
                        for ddy in (-1, 0, 1):
                            for ddz in (-1, 0, 1):
                                for j in grid.get((gx+ddx, gy+ddy, gz+ddz), ()):
                                    if j <= i:
                                        continue
                                    if bbox_dist(comp["bbox"], components[j]["bbox"]) <= cluster_dist:
                                        union_c(i, j)

            # Build zones dict
            zones_dict = {}
            for i in range(len(components)):
                zones_dict.setdefault(find_c(i), []).append(components[i])
            self._zones_dict = zones_dict
            wm.progress_update(50)
            self._phase = _PH_ZONES

        # ── Phase 4: pre-compute per-zone Python geometry (one tick) ──────────
        elif self._phase == _PH_ZONES:
            all_verts    = self._all_verts
            all_faces    = self._all_faces
            all_face_m   = self._all_face_mats
            all_uvs      = self._all_uvs
            all_colors   = self._all_colors
            scale        = self._scale
            center_geom  = self._center_geometry

            zones_list = []
            for zone_comps in self._zones_dict.values():
                zvi = set()
                zfi = []
                for comp in zone_comps:
                    zvi.update(comp["vert_indices"])
                    zfi.extend(comp["face_indices"])

                cx = cy = cz = 0.0
                if center_geom:
                    xs = [all_verts[v][0] for v in zvi]
                    ys = [all_verts[v][1] for v in zvi]
                    zs = [all_verts[v][2] for v in zvi]
                    cx = (min(xs) + max(xs)) * 0.5
                    cy = (min(ys) + max(ys)) * 0.5
                    cz = (min(zs) + max(zs)) * 0.5

                old2new = {}
                zone_verts  = []
                zone_uvs    = []
                zone_colors = []
                for old in sorted(zvi):
                    old2new[old] = len(zone_verts)
                    v = all_verts[old]
                    zone_verts.append((
                        (v[0] - cx) * scale,
                        (v[1] - cy) * scale,
                        (v[2] - cz) * scale,
                    ))
                    zone_uvs.append(all_uvs[old])
                    zone_colors.append(all_colors[old])

                zone_faces    = []
                zone_face_m   = []
                for fi in zfi:
                    f = all_faces[fi]
                    zone_faces.append((old2new[f[0]], old2new[f[1]], old2new[f[2]]))
                    zone_face_m.append(all_face_m[fi])

                zones_list.append({
                    "verts":     zone_verts,
                    "faces":     zone_faces,
                    "uvs":       zone_uvs,
                    "colors":    zone_colors,
                    "face_mats": zone_face_m,
                })

            self._zones_list   = zones_list
            self._total_zones  = len(zones_list)
            self._zone_idx     = 0
            # Free the big intermediate lists — no longer needed
            self._all_verts = self._all_faces = self._all_face_mats = None
            self._all_uvs   = self._all_colors = None
            self._uf_parent = self._components = self._comp_parent = None
            self._zones_dict = None
            wm.progress_update(60)
            self._phase = _PH_MESHES

        # ── Phase 5: create one Blender mesh per tick ─────────────────────────
        elif self._phase == _PH_MESHES:
            if self._zone_idx >= self._total_zones:
                self._finish(context)
                return {'FINISHED'}

            zone      = self._zones_list[self._zone_idx]
            zone_idx  = self._zone_idx

            mesh = bpy.data.meshes.new(f"Zone_{zone_idx}_Mesh")
            obj  = bpy.data.objects.new(f"Zone_{zone_idx}", mesh)
            context.collection.objects.link(obj)

            mesh.from_pydata(zone["verts"], [], zone["faces"])
            mesh.update()

            if self._recalc:
                bm = bmesh.new()
                bm.from_mesh(mesh)
                bmesh.ops.recalc_face_normals(bm, faces=bm.faces)
                bm.to_mesh(mesh)
                bm.free()
                mesh.update()

            used_mats  = sorted(set(zone["face_mats"]))
            mat_to_slot = {}
            for mat_idx in used_mats:
                if mat_idx < len(self._blender_materials):
                    mat_to_slot[mat_idx] = len(obj.data.materials)
                    obj.data.materials.append(self._blender_materials[mat_idx])

            for fi, mat_idx in enumerate(zone["face_mats"]):
                if mat_idx in mat_to_slot:
                    mesh.polygons[fi].material_index = mat_to_slot[mat_idx]

            if zone["uvs"]:
                uv_layer  = mesh.uv_layers.new(name="UVMap")
                zone_uvs  = zone["uvs"]
                for fi, face in enumerate(zone["faces"]):
                    for li, vi in enumerate(face):
                        if vi < len(zone_uvs):
                            uv_layer.data[fi * 3 + li].uv = zone_uvs[vi]

            if zone["colors"]:
                clayer     = mesh.vertex_colors.new(name="Color")
                zone_col   = zone["colors"]
                for fi, face in enumerate(zone["faces"]):
                    for li, vi in enumerate(face):
                        if vi < len(zone_col):
                            clayer.data[fi * 3 + li].color = zone_col[vi]

            obj.parent = self._world_parent

            if self._dist_zones and self._total_zones > 1:
                angle = (2 * math.pi * zone_idx) / self._total_zones
                obj.location = (
                    math.cos(angle) * self._dist_radius,
                    math.sin(angle) * self._dist_radius,
                    0.0,
                )

            self._zone_idx += 1
            pct = 60 + int(self._zone_idx / self._total_zones * 40)
            wm.progress_update(pct)

        for area in context.screen.areas:
            area.tag_redraw()

        return {'RUNNING_MODAL'}

    # ── Helpers ───────────────────────────────────────────────────────────────

    def _finish(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
        wm.progress_end()
        if self._world_parent:
            self._world_parent.select_set(True)
            context.view_layer.objects.active = self._world_parent
        self.report({'INFO'}, f"Imported {self._total_zones} zone(s) from {self._bsp_name}")

    def _cancel_modal(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
        wm.progress_end()

    def cancel(self, context):
        self._cancel_modal(context)
